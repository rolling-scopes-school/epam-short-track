export const mockOne = () => {
  console.log('foo');
};

export const mockTwo = () => {
  console.log('bar');
};

export const mockThree = () => {
  console.log('baz');
};

export const unmockedFunction = () => {
  console.log('I am not mocked');
};
